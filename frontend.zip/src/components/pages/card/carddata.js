import card1 from './card1.jpg';
import card2 from './card2.jpg';
import card3 from './card3.jpg';
import card4 from './card4.jpg';
import card5 from './card4.jpg';
import card6 from './card3.jpg';
import card7 from './card2.jpg';
import card8 from './card1.jpg';
const Carddata = [
    {
        id: 1,
        img:card1,
    },
    {
        id: 2,
        img:card2,
    },
    {
        id: 3,
        img:card3,

    },
    {
        id: 4,
        img:card4,

    },
    {
        id: 5,
        img:card5,

    },
    {
        id: 6,
        img:card6,

    },
    {
        id: 7,
        img:card7,

    },
    {
        id: 8,
        img:card8,

    }
]
export default Carddata;
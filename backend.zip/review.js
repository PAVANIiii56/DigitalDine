import mongoose from "mongoose";
const Schema = mongoose.Schema
let ReviewSchema = new Schema({
    fname:{
        type: String,
    },
    lname:{
        type:String,
    },
    email: {
        type: String,
    },
    number: {
        type: String,
    },    
    day: {
        type: String,
    },
    msg: {
        type: String,
    },

});
export default mongoose.model("review",ReviewSchema);